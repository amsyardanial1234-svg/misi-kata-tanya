MISI KATA TANYA BERSAMA SI PENJELAJAH

Cara deploy ke Netlify:
1. Ekstrak fail ZIP ini ke komputer.
2. Buka https://app.netlify.com/drop
3. Seret folder yang mengandungi index.html ke ruang Netlify Drop.
4. Tunggu sehingga Netlify memberikan URL laman web.
5. Buka URL itu untuk menguji laman.
6. Masukkan URL tersebut ke widget iFrame Embed di Jotform.

Fail utama: index.html
Laman ini menggunakan HTML, CSS dan JavaScript biasa; tiada kredit AI atau build command diperlukan.
